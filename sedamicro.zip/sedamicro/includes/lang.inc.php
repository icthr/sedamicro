<?php
/**
 * @file
 * Contents of the language translations.
 *
 * TODO: change this to i18ln!
 * This is the only place that going cross language is causing
 * semi-standard issues. Has to be moved to using t() in Drupal and
 * similar in WP.
 *
 *  * @category Language
 *  * @package SedaMicro
 *  * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License
 *  * @link http://www.ict4hr.net.
 */

$lang_en = array(
  "choose_file" => "Please select or record the ffile to be uploaded",
  "title" => "Title",
  "refresh" => "Refresh",
  "upload" => "Upload",
  "file_success" => "File was successfully uploaded",
  "see_here" => "See it here",
  "error" => "An error occurred",
  "please_answer" => "Please answer the question below",
  "sorry_not_uploaded" => "Sorry, your file was not uploaded",
);
$lang = array(
  "choose_file" => "لطفا آنچه میخواهید بفرستید را ضبط یا ارسال کنید.",
  "title" => " عنوان",
  "refresh" => "بارگذاری مجدد صفحه",
  "upload" => "ارسال",
  "file_success" => "فایل با موفقیت ارسال شد. میتوانید آنرا",
  "see_here" => "اینجا ببینید",
  "error" => "مشکلی پیش آمده.",
  "please_answer" => "لطفا به سوال زیر پاسخ دهید",
  "sorry_not_uploaded" => "متاسفانه فایل شما ارسال نشده",
);
